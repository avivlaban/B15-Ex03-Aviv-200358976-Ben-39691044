﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GarageLogic
{
    public enum eClientStatus
    {
        InRepair = 1,
        Repaired = 2,
        Paid = 3,
        All = 4
    }
}
