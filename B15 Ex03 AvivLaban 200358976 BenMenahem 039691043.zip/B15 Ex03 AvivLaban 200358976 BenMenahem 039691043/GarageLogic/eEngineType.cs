﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GarageLogic
{
    public enum eEngineType
    {
        Gas = 1,
        Electric = 2
    }
}
