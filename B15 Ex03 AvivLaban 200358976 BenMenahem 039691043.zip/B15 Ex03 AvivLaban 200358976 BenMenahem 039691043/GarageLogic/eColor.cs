﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GarageLogic
{
    public enum eColor
    {
        Green = 1,
        Black = 2,
        White = 3,
        Red = 4
    }
}
