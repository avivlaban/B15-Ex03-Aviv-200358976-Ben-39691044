﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GarageLogic
{
    public enum eLicenceType
    {
        A = 1,
        A2 = 2,
        AB = 3,
        B1 = 4
    }
}
