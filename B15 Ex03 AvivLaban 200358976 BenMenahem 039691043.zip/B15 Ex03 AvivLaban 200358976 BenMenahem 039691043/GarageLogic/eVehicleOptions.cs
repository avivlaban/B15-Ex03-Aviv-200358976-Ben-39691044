﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GarageLogic
{
    public enum eVehicleOptions
    {
        Motorcycle = 1,
        Car = 2,
        Truck = 3,
    }
}
